// ToDoItem.js
import React, { useState } from "react";

export const ToDoItem = ({ todo, setTodos }) => {
  const [editing, setEditing] = useState(false);
  const [newText, setNewText] = useState(todo.text);

  const handleDelete = () => {
    setTodos((prevTodos) => prevTodos.filter((item) => item.id !== todo.id));
  };

  const handleComplete = () => {
    setTodos((prevTodos) =>
      prevTodos.map((item) =>
        item.id === todo.id ? { ...item, completed: !item.completed } : item
      )
    );
  };

  const handleEdit = () => {
    if (editing) {
      setTodos((prevTodos) =>
        prevTodos.map((item) =>
          item.id === todo.id ? { ...item, text: newText } : item
        )
      );
    }
    setEditing(!editing);
  };

  return (
    <div>
      {editing ? (
        <input
          type="text"
          value={newText}
          onChange={(e) => setNewText(e.target.value)}
        />
      ) : (
        <span style={{ textDecoration: todo.completed ? "line-through" : "" }}>
          {todo.text}
        </span>
      )}
      <button onClick={handleComplete}>
        {todo.completed ? "Undo" : "Complete"}
      </button>
      <button onClick={handleDelete}>Delete</button>
      <button onClick={handleEdit}>{editing ? "Save" : "Edit"}</button>
    </div>
  );
};


