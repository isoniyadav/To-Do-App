import React from "react";

export const Header = () => {
  return <h1>To-Do App</h1>;
};


