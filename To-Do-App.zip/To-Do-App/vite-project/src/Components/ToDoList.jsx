// ToDoList.js
import React from "react";
import { ToDoItem} from "./ToDoItem";

export const ToDoList = ({ todos, setTodos }) => {
  return (
    <div>
      {todos.map((todo) => (
        <ToDoItem key={todo.id} todo={todo} setTodos={setTodos} />
      ))}
    </div>
  );
};

