import React, { useState } from "react";
import { Header} from "./Components/Header";
import { ToDoList} from "./Components/ToDoList";
import "./App.css";

const App = () => {
  const [todos, setTodos] = useState([]);
  const [newTodo, setNewTodo] = useState("");

  const handleAddTodo = () => {
    const newTodoItem = {
      id: Date.now(), 
      text: newTodo,
      completed: false,
    };
    setTodos([...todos, newTodoItem]);
    setNewTodo(""); 
  };

  return (
    <div> {/* Parent container wrapping all JSX elements */}
      <Header />
      <input
        type="text"
        value={newTodo}
        onChange={(e) => setNewTodo(e.target.value)}
        placeholder="Add a new task"
      />
      <button onClick={handleAddTodo}>Add</button>
      <ToDoList todos={todos} setTodos={setTodos} />
    </div>
  );
};

export default App;
